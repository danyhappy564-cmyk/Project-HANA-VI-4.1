export type IEmptyRequestData = {};
